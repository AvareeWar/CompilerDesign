#include	<stdlib.h>
#include	<stdio.h>

int		array[10]	= {0,1,2,3,4,5,6,7,8,9};

int*		f		(int i
				)
{
  return(&array[i]);
}

int		main		()
{
  *f(6)	=	17;

  int	i;

  for  (i = 0;  i < 10;  i++)
    printf("array[%d] = %d\n",i,array[i]);

  return(EXIT_SUCCESS);
}
